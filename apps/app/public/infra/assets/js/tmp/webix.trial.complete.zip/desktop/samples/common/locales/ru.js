const ruLocale = {
	App: "Приложение",
	"Close all": "Закрыть все",
};
