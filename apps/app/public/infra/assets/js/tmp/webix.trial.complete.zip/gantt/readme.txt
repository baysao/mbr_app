Webix Gantt v.10.0.1
================

https://webix.com

If you don't know where to start - check 

- https://webix.com/quick-start/#!/1
- https://docs.webix.com/desktop__gantt.html
- https://forum.webix.com


### License terms

Webix Gantt library is licensed under Webix Trial Developer License Agreement
Check - Webix Trial Developer License Agreement file in this archive

** What does it means in human terms **

- This version is for evaluation purposes only
- Evaluation period is 30 days
- You cannot continue using this beyond that period (30 days)



### Commercial license and Support

You can buy commercial license and support subscription at https://webix.com/licenses/

If you have questions about functionality of the component 
or have some issue with API and behavior of the component,
please contact us at support@webix.com


(c) XB Software Ltd. 2022