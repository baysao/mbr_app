function login(url) {
	return Promise.resolve({ user: "Alex Brown", id: 1 });
}
